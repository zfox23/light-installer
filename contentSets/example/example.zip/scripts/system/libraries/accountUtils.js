//
//  accountUtils.js
//  scripts/system/libraries/libraries
//
//  Copyright 2017 High Fidelity, Inc.
//

openLoginWindow = function openLoginWindow() {
    Menu.triggerOption("Login/Sign Up");
};        
